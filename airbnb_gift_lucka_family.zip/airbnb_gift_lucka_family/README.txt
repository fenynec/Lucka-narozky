
# 🎂 Dárek pro Lucku – rodinná verze (finální)

- Přátelský narozeninový styl s konfetami.
- Žádný odkaz na Airbnb; domluva proběhne přes e‑mail.
- Přidané tipy v okolí (Nissi Beach, WaterWorld, Cape Greco, Blue Lagoon, Parko Paliatso) se
  zobrazují s fotografiemi hotlinkovanými z Wikimedia Commons a s uvedením autorů a licencí.

## Co si upravit
1) V `index.html` nahraď `example@email.cz` svým e‑mailem (2x).
2) Přidej vlastní fotky interiéru do `assets/` a uprav sekci „Galerie apartmánu“.
3) Chceš WhatsApp/Messenger? Přidej vedle tlačítka e‑mailu další `<a>` s odkazem `https://wa.me/` nebo `https://m.me/`.

## Poznámka k licencím fotek
Fotky okolí jsou načítané přímo z Wikimedia Commons (hotlink), autoři a licence jsou zmíněny u sekce.
Pokud je budeš stahovat lokálně, dodej kredit i na stránce.
